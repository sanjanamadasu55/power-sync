Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "c:\Users\Lenovo\Desktop\smart power execution\agent"
WshShell.Run """C:\Program Files\Python310\python.exe"" setup_gui.py", 0, False
