@echo off 
title PowerSync Dashboard 
cd /d "%~dp0" 
npm run tauri dev 
