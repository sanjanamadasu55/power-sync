@echo off
REM ============================================
REM   PowerSync ADMIN Setup (Hidden Execution)
REM ============================================
title PowerSync Admin Setup
color 0A

echo.
echo  ========================================
echo     PowerSync ADMIN Installer
echo  ========================================
echo.

REM Get script directory
set "SCRIPT_DIR=%~dp0"
set "SERVER_DIR=%SCRIPT_DIR%server"
set "DASHBOARD_DIR=%SCRIPT_DIR%dashboard"

REM Find Python
where python >nul 2>&1
if %errorLevel% neq 0 (
    echo  [X] Python not found! Please install Python first.
    pause
    exit /b 1
)
echo  [OK] Python found

REM Install server dependencies
echo.
echo  [*] Installing server dependencies...
cd /d "%SERVER_DIR%"
pip install -r requirements.txt -q
echo  [OK] Server dependencies installed

REM Check for Node.js
echo.
echo  [*] Checking Node.js...
where npm >nul 2>&1
if %errorLevel% neq 0 (
    echo  [X] Node.js not found! Please install Node.js first.
    echo      Download from: https://nodejs.org/
    pause
    exit /b 1
)
echo  [OK] Node.js found

REM Install dashboard dependencies
echo.
echo  [*] Installing dashboard dependencies (this may take a few minutes)...
cd /d "%DASHBOARD_DIR%"
if not exist "package.json" (
    echo  [X] package.json not found in dashboard folder!
    pause
    exit /b 1
)
call npm install
if %errorLevel% neq 0 (
    echo  [X] npm install failed! Check the error above.
    pause
    exit /b 1
)
echo  [OK] Dashboard dependencies installed

REM Check for Rust (needed for Tauri)
echo.
echo  [*] Checking Rust...
where cargo >nul 2>&1
if %errorLevel% neq 0 (
    echo  [!] Rust not found. Installing Rust automatically...
    echo.
    echo  [*] Downloading Rust installer...
    powershell -Command "Invoke-WebRequest -Uri 'https://win.rustup.rs/x86_64' -OutFile '%TEMP%\rustup-init.exe'"
    if exist "%TEMP%\rustup-init.exe" (
        echo  [*] Installing Rust (this may take a few minutes)...
        "%TEMP%\rustup-init.exe" -y --default-toolchain stable
        del "%TEMP%\rustup-init.exe"
        echo  [OK] Rust installed successfully
        echo.
        echo  [*] Refreshing PATH for Rust...
        REM Add Cargo to current session PATH
        set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
        echo  [OK] Rust PATH updated
    ) else (
        echo  [X] Failed to download Rust installer.
        echo      Please install manually from: https://rustup.rs/
        pause
        exit /b 1
    )
)
echo  [OK] Rust ready

REM Create VBS launchers for hidden execution
echo.
echo  [*] Creating hidden launchers...

REM Server hidden launcher
echo Set WshShell = CreateObject("WScript.Shell") > "%SERVER_DIR%\start_server_hidden.vbs"
echo WshShell.CurrentDirectory = "%SERVER_DIR%" >> "%SERVER_DIR%\start_server_hidden.vbs"
echo WshShell.Run "pythonw -m uvicorn main:app --host 0.0.0.0 --port 8000", 0, False >> "%SERVER_DIR%\start_server_hidden.vbs"

REM Dashboard hidden launcher
echo Set WshShell = CreateObject("WScript.Shell") > "%DASHBOARD_DIR%\start_dashboard_hidden.vbs"
echo WshShell.CurrentDirectory = "%DASHBOARD_DIR%" >> "%DASHBOARD_DIR%\start_dashboard_hidden.vbs"
echo WshShell.Run "cmd /c npm run tauri dev", 0, False >> "%DASHBOARD_DIR%\start_dashboard_hidden.vbs"

echo  [OK] Hidden launchers created

REM Setup auto-start (Startup folder)
echo.
echo  [*] Setting up auto-start...
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
copy "%SERVER_DIR%\start_server_hidden.vbs" "%STARTUP%\PowerSync_Server.vbs" >nul
echo  [OK] Server auto-start configured

REM Create Desktop shortcuts using VBS launchers
echo.
echo  [*] Creating desktop shortcuts...
set "DESKTOP=%USERPROFILE%\Desktop"

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\PowerSync Server.lnk'); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%SERVER_DIR%\start_server_hidden.vbs\"'; $s.Save()"
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\PowerSync Dashboard.lnk'); $s.TargetPath = 'wscript.exe'; $s.Arguments = '\"%DASHBOARD_DIR%\start_dashboard_hidden.vbs\"'; $s.Save()"
echo  [OK] Desktop shortcuts created (run hidden)

REM Start server now (hidden)
echo.
echo  [*] Starting server (hidden)...
start "" wscript.exe "%SERVER_DIR%\start_server_hidden.vbs"

REM Wait for server
echo  [*] Waiting for server...
timeout /t 5 /nobreak >nul

REM Check server
powershell -Command "try { Invoke-RestMethod -Uri 'http://localhost:8000/health' -TimeoutSec 3 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if %errorLevel% equ 0 (
    echo  [OK] Server is running at http://localhost:8000
) else (
    echo  [!] Server starting in background...
)

echo.
echo  ========================================
echo     ADMIN SETUP COMPLETE!
echo  ========================================
echo.
echo   Server running invisibly in background
echo   Dashboard shortcut runs without terminal
echo.
echo   Desktop shortcuts:
echo   - PowerSync Server (hidden)
echo   - PowerSync Dashboard (hidden)
echo.
echo  ========================================
echo.

set /p OPEN_DASH="Open Dashboard now? (Y/N): "
if /i "%OPEN_DASH%"=="Y" (
    start "" wscript.exe "%DASHBOARD_DIR%\start_dashboard_hidden.vbs"
)

echo  Press any key to exit...
pause >nul
