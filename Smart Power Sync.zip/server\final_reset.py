
import sqlite3
from datetime import datetime

DB_PATH = 'c:/Users/Lenovo/Desktop/smart power execution/server/power_management.db'

def final_reset():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # 1. Update Sanjana to Active and Heartbeat to Now
    now_str = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f')
    cursor.execute('UPDATE devices SET status = "active", last_heartbeat = ?, system_type = "admin" WHERE hostname = "Sanjana"', (now_str,))
    conn.commit()
    
    # 2. Verify
    cursor.execute('SELECT hostname, status, system_type FROM devices WHERE hostname = "Sanjana"')
    result = cursor.fetchone()
    print(f"Final Sanjana State: {result}")
    
    conn.close()

if __name__ == "__main__":
    final_reset()
