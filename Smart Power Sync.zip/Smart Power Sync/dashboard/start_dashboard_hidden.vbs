Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "c:\Users\manus\Desktop\Major-Project\dashboard"
' Run npm in background - dashboard will open as GUI 
WshShell.Run "cmd /c npm run tauri dev", 0, False
