@echo off 
title PowerSync Dashboard 
cd /d "C:\Users\manus\Desktop\Major-Project\dashboard" 
npm run tauri dev 
