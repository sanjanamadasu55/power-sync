Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -Command ""Start-Process -FilePath 'C:\Program Files\Python310\python.exe' -ArgumentList '-m uvicorn main:app --host 0.0.0.0 --port 8000' -WorkingDirectory 'c:\Users\manus\Desktop\Major-Project\server' -WindowStyle Hidden""", 0, False
