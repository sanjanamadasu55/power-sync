@echo off 
title PowerSync Server 
cd /d "C:\Users\manus\Desktop\Major-Project\server" 
python -m uvicorn main:app --host 0.0.0.0 --port 8000 
