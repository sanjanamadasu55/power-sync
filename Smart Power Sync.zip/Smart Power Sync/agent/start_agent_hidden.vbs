Set WshShell = CreateObject("WScript.Shell") 
WshShell.CurrentDirectory = "C:\Users\manus\Desktop\Major-Project\agent" 
WshShell.Run "pythonw agent.py", 0, False 
