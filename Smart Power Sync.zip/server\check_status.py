import sqlite3
try:
    conn = sqlite3.connect('power_management.db')
    cursor = conn.cursor()
    cursor.execute("SELECT hostname, status, last_heartbeat FROM devices WHERE hostname='Sanjana'")
    row = cursor.fetchone()
    print(f"Device Status: {row}")
    conn.close()
except Exception as e:
    print(f"Error: {e}")
