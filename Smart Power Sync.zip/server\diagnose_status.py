from database import SessionLocal
from models import Device, Settings
from datetime import datetime, timedelta

def run_diagnostics():
    db = SessionLocal()
    try:
        devices = db.query(Device).all()
        settings = {s.key: s.value for s in db.query(Settings).all()}
        timeout = int(settings.get('heartbeat_timeout_seconds', '120'))
        
        print(f"--- Server Context ---")
        print(f"UTC Now: {datetime.utcnow()}")
        print(f"Local Now: {datetime.now()}")
        print(f"Timeout Setting: {timeout}s")
        print(f"\n--- Device List ---")
        
        for d in devices:
            sys_type = str(d.system_type or '').strip().lower()
            # ONLY admin systems are protected from auto-hibernation/shutdown
            is_protected = "admin" in sys_type
            
            eff_timeout = 3600 if is_protected or d.hostname == "Sanjana" else timeout
            eff_threshold = datetime.utcnow() - timedelta(seconds=eff_timeout)
            
            is_offline_calc = False
            if d.last_heartbeat:
                is_offline_calc = d.last_heartbeat < eff_threshold
            else:
                is_offline_calc = True
                
            print(f"ID: {d.device_id}")
            print(f"  Host: {d.hostname}")
            print(f"  Status: {d.status}")
            print(f"  Type: {d.system_type}")
            print(f"  LastHB: {d.last_heartbeat}")
            print(f"  Protected: {is_protected}")
            print(f"  EffTimeout: {eff_timeout}s")
            print(f"  Threshold: {eff_threshold}")
            print(f"  Logic Says Offline: {is_offline_calc}")
            print("-" * 30)
            
    finally:
        db.close()

if __name__ == "__main__":
    run_diagnostics()
