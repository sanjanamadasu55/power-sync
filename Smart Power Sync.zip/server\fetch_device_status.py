import urllib.request
import json

try:
    with urllib.request.urlopen('http://localhost:8000/api/devices') as response:
        data = json.loads(response.read().decode())
        for d in data['devices']:
            if d['hostname'] == 'Sanjana':
                print(f"Hostname: {d['hostname']}")
                print(f"Status: {d['status']}")
                print(f"Last Power State: {d.get('last_power_state')}")
                print(f"Last Heartbeat: {d.get('last_heartbeat')}")
except Exception as e:
    print(f"Error: {e}")
