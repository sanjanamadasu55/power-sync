@echo off
REM ============================================
REM   PowerSync AGENT Setup (Hidden Execution)
REM ============================================
title PowerSync Agent Setup
color 0B

echo.
echo  ========================================
echo     PowerSync AGENT Installer
echo  ========================================
echo.

REM Get script directory
set "SCRIPT_DIR=%~dp0"
set "AGENT_DIR=%SCRIPT_DIR%agent"

REM Find Python
where python >nul 2>&1
if %errorLevel% neq 0 (
    echo  [X] Python not found! Please install Python first.
    pause
    exit /b 1
)
echo  [OK] Python found

for /f "delims=" %%i in ('where python') do set "PYTHON_EXE=%%i" & goto :found_python
:found_python

REM Install agent dependencies
echo.
echo  [*] Installing agent dependencies...
cd /d "%AGENT_DIR%"
pip install -r requirements.txt -q
pip show PyQt6 >nul 2>&1 || pip install PyQt6 -q
echo  [OK] Dependencies installed

REM Create hidden launcher
echo.
echo  [*] Creating hidden launcher...
echo Set WshShell = CreateObject("WScript.Shell") > "%AGENT_DIR%\start_agent_hidden.vbs"
echo WshShell.CurrentDirectory = "%AGENT_DIR%" >> "%AGENT_DIR%\start_agent_hidden.vbs"
echo WshShell.Run "pythonw agent.py", 0, False >> "%AGENT_DIR%\start_agent_hidden.vbs"
echo  [OK] Hidden launcher created

REM Setup auto-start
echo.
echo  [*] Setting up auto-start...
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
copy "%AGENT_DIR%\start_agent_hidden.vbs" "%STARTUP%\PowerSync_Agent.vbs" >nul
echo  [OK] Agent auto-start configured

REM Create Settings shortcut
echo.
echo  [*] Creating desktop shortcut...
set "DESKTOP=%USERPROFILE%\Desktop"
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\PowerSync Settings.lnk'); $s.TargetPath = '%PYTHON_EXE%'; $s.Arguments = '\"%AGENT_DIR%\setup_gui.py\"'; $s.WorkingDirectory = '%AGENT_DIR%'; $s.Save()"
echo  [OK] Settings shortcut created

echo.
echo  ========================================
echo     Opening Configuration GUI...
echo  ========================================
echo.
echo  Configure the agent in the GUI window.
echo.

REM Launch setup GUI and wait for it
start "" /wait "%PYTHON_EXE%" "%AGENT_DIR%\setup_gui.py"

REM Start agent hidden
echo.
echo  [*] Starting agent (hidden)...
start "" wscript.exe "%AGENT_DIR%\start_agent_hidden.vbs"
echo  [OK] Agent running in background

echo.
echo  ========================================
echo     AGENT SETUP COMPLETE!
echo  ========================================
echo.
echo   Agent running invisibly in background
echo   Auto-starts on login (hidden)
echo.
echo   Desktop shortcut:
echo   - PowerSync Settings
echo.
echo  ========================================
echo.
echo  Press any key to exit...
pause >nul
