import { useState, useEffect } from 'react'
import {
    Monitor, Power, Sun, Moon, Zap, WifiOff,
    Settings, BarChart3, Activity, X, RefreshCw,
    PowerOff, Play, AlertTriangle, TrendingUp, Leaf, DollarSign, Save,
    List, Bell, Search, Filter, CheckCircle, Clock, Trash2, Plus, ToggleLeft, ToggleRight,
    Download
} from 'lucide-react'
import { XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import './App.css'

const API_URL = 'http://localhost:8000'

const statusColors: Record<string, string> = {
    active: '#22c55e',
    passive: '#eab308',
    deep_idle: '#f97316',
    offline: '#ef4444'
}

const statusLabels: Record<string, string> = {
    active: 'Active',
    passive: 'Idle',
    deep_idle: 'Deep Idle',
    offline: 'Offline'
}



function App() {
    const [devices, setDevices] = useState<any[]>([])
    const [analytics, setAnalytics] = useState<any>(null)
    const [settings, setSettings] = useState<any[]>([])
    const [selectedDevice, setSelectedDevice] = useState<string | null>(null)
    const [deviceDetail, setDeviceDetail] = useState<any>(null)
    const [loading, setLoading] = useState(true)
    const [activeTab, setActiveTab] = useState('dashboard')
    const [savingSettings, setSavingSettings] = useState(false)

    // New state for Devices page
    const [searchQuery, setSearchQuery] = useState('')
    const [statusFilter, setStatusFilter] = useState('all')
    const [typeFilter, setTypeFilter] = useState('all')
    const [selectedDevices, setSelectedDevices] = useState<string[]>([])

    // New state for Activity page
    const [events, setEvents] = useState<any[]>([])
    const [eventTypeFilter, setEventTypeFilter] = useState('all')

    // New state for Alerts page
    const [alerts, setAlerts] = useState<any[]>([])
    const [alertRules, setAlertRules] = useState<any[]>([])
    const [alertsTab, setAlertsTab] = useState('alerts') // 'alerts' or 'rules'
    const [unacknowledgedCount, setUnacknowledgedCount] = useState(0)

    // Loading and toast states for action buttons
    const [actionLoading, setActionLoading] = useState<string | null>(null)
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)

    // New Alert Rule form state
    const [newRule, setNewRule] = useState({ name: '', rule_type: 'offline_timeout', threshold_value: 60 })

    // Show toast message
    const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
        setToast({ message, type })
        setTimeout(() => setToast(null), 3000)
    }

    const fetchData = async (initial = false) => {
        if (initial) setLoading(true)
        try {
            const [devicesRes, analyticsRes] = await Promise.all([
                fetch(`${API_URL}/api/devices`),
                fetch(`${API_URL}/api/analytics`)
            ])
            if (devicesRes.ok) {
                const data = await devicesRes.json()
                setDevices(data.devices)
            }
            if (analyticsRes.ok) {
                const data = await analyticsRes.json()
                setAnalytics(data)
            }
        } catch (error) {
            console.error('Failed to fetch data:', error)
        } finally {
            setLoading(false)
        }
    }

    const fetchSettings = async () => {
        try {
            const res = await fetch(`${API_URL}/api/settings`)
            if (res.ok) {
                const data = await res.json()
                setSettings(data.settings)
            }
        } catch (error) {
            console.error('Failed to fetch settings:', error)
        }
    }

    const updateSetting = async (key: string, value: any) => {
        setSavingSettings(true)
        try {
            await fetch(`${API_URL}/api/settings`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key, value })
            })
            await fetchSettings()
        } catch (error) {
            console.error('Failed to update setting:', error)
        } finally {
            setSavingSettings(false)
        }
    }

    const fetchDeviceDetail = async (deviceId: string) => {
        setActionLoading(`detail-${deviceId}`)
        try {
            const res = await fetch(`${API_URL}/api/devices/${deviceId}`)
            if (res.ok) {
                const data = await res.json()
                setDeviceDetail(data)
            }
        } catch (error) {
            console.error('Failed to fetch device detail:', error)
        } finally {
            setActionLoading(null)
        }
    }

    const sendCommand = async (deviceId: string, command: string, message = '', hostname = 'device') => {
        setActionLoading(`${command.toLowerCase()}-${deviceId}`)
        try {
            const res = await fetch(`${API_URL}/api/devices/${deviceId}/command`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command, message })
            })
            if (res.ok) {
                showToast(`${command} command sent to ${hostname}`, 'success')
                await Promise.all([fetchData(), fetchEvents()])
            } else {
                showToast(`Failed to send ${command.toLowerCase()} command`, 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
            console.error('Failed to send command:', error)
        }
        setActionLoading(null)
    }

    const wakeDevice = async (deviceId: string, hostname = 'device') => {
        setActionLoading(`wake-${deviceId}`)
        try {
            const res = await fetch(`${API_URL}/api/devices/${deviceId}/wake`, { method: 'POST' })
            if (res.ok) {
                showToast(`Wake packet sent to ${hostname}`, 'success')
                await Promise.all([fetchData(), fetchEvents()])
            } else {
                showToast('Failed to send wake packet', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
            console.error('Failed to wake device:', error)
        }
        setActionLoading(null)
    }

    // Fetch power events for Activity page
    const fetchEvents = async () => {
        setActionLoading('refresh-events')
        try {
            const res = await fetch(`${API_URL}/api/events?limit=100`)
            if (res.ok) {
                const data = await res.json()
                setEvents(data.events)
            }
        } catch (error) {
            console.error('Failed to fetch events:', error)
        } finally {
            setActionLoading(null)
        }
    }

    // Fetch alerts
    const fetchAlerts = async () => {
        try {
            const res = await fetch(`${API_URL}/api/alerts`)
            if (res.ok) {
                const data = await res.json()
                setAlerts(data.alerts)
                setUnacknowledgedCount(data.unacknowledged_count)
            }
        } catch (error) {
            console.error('Failed to fetch alerts:', error)
        }
    }

    // Fetch alert rules
    const fetchAlertRules = async () => {
        try {
            const res = await fetch(`${API_URL}/api/alert-rules`)
            if (res.ok) {
                const data = await res.json()
                setAlertRules(data)
            }
        } catch (error) {
            console.error('Failed to fetch alert rules:', error)
        }
    }

    // Acknowledge alert
    const acknowledgeAlert = async (alertId: number) => {
        setActionLoading(`ack-${alertId}`)
        try {
            const res = await fetch(`${API_URL}/api/alerts/${alertId}/acknowledge`, { method: 'POST' })
            if (res.ok) {
                showToast('Alert acknowledged', 'success')
                await fetchAlerts()
            } else {
                showToast('Failed to acknowledge alert', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Delete alert
    const deleteAlert = async (alertId: number) => {
        setActionLoading(`del-${alertId}`)
        try {
            const res = await fetch(`${API_URL}/api/alerts/${alertId}`, { method: 'DELETE' })
            if (res.ok) {
                showToast('Alert deleted', 'info')
                await fetchAlerts()
            } else {
                showToast('Failed to delete alert', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Delete activity log
    const deleteEvent = async (eventId: number) => {
        setActionLoading(`del-event-${eventId}`)
        try {
            const res = await fetch(`${API_URL}/api/events/${eventId}`, { method: 'DELETE' })
            if (res.ok) {
                showToast('Activity log deleted', 'info')
                await fetchEvents()
            } else {
                showToast('Failed to delete log', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Helper functions for rendering
    const formatTimestamp = (ts: string) => {
        const date = new Date(ts)
        return date.toLocaleString()
    }

    // Create alert rule
    const createAlertRule = async () => {
        if (!newRule.name) {
            showToast('Please provide a rule name', 'error')
            return
        }
        setActionLoading('create-rule')
        try {
            const res = await fetch(`${API_URL}/api/alert-rules`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...newRule, is_enabled: true })
            })
            if (res.ok) {
                showToast('Alert rule created!', 'success')
                setNewRule({ name: '', rule_type: 'offline_timeout', threshold_value: 60 })
                await fetchAlertRules()
            } else {
                showToast('Failed to create rule', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Delete alert rule
    const deleteAlertRule = async (ruleId: number) => {
        setActionLoading(`del-rule-${ruleId}`)
        try {
            const res = await fetch(`${API_URL}/api/alert-rules/${ruleId}`, { method: 'DELETE' })
            if (res.ok) {
                showToast('Rule deleted', 'info')
                await fetchAlertRules()
            } else {
                showToast('Failed to delete rule', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Toggle alert rule
    const toggleAlertRule = async (ruleId: number, isEnabled: boolean) => {
        setActionLoading(`toggle-rule-${ruleId}`)
        try {
            const res = await fetch(`${API_URL}/api/alert-rules/${ruleId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ is_enabled: !isEnabled })
            })
            if (res.ok) {
                showToast(isEnabled ? 'Rule disabled' : 'Rule enabled', 'success')
                await fetchAlertRules()
            } else {
                showToast('Failed to update rule', 'error')
            }
        } catch (error) {
            showToast('Network error', 'error')
        }
        setActionLoading(null)
    }

    // Wake multiple devices
    const wakeSelectedDevices = async () => {
        setActionLoading('bulk-wake')
        let successCount = 0
        for (const deviceId of selectedDevices) {
            try {
                const res = await fetch(`${API_URL}/api/devices/${deviceId}/wake`, { method: 'POST' })
                if (res.ok) successCount++
            } catch (e) { console.error(e) }
        }
        showToast(`Wake command sent to ${successCount} devices`, 'success')
        setSelectedDevices([])
        setActionLoading(null)
        await Promise.all([fetchData(), fetchEvents()])
    }

    // Shutdown multiple devices
    const shutdownSelectedDevices = async () => {
        setActionLoading('bulk-shutdown')
        let successCount = 0
        for (const deviceId of selectedDevices) {
            try {
                const res = await fetch(`${API_URL}/api/devices/${deviceId}/command`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command: 'SHUTDOWN', message: 'Bulk shutdown' })
                })
                if (res.ok) successCount++
            } catch (e) { console.error(e) }
        }
        showToast(`Shutdown command sent to ${successCount} devices`, 'success')
        setSelectedDevices([])
        setActionLoading(null)
        await Promise.all([fetchData(), fetchEvents()])
    }

    useEffect(() => {
        fetchData(true)
        fetchSettings()
        const interval = setInterval(() => fetchData(false), 5000)
        return () => clearInterval(interval)
    }, [])

    useEffect(() => {
        if (selectedDevice) {
            fetchDeviceDetail(selectedDevice)
        }
    }, [selectedDevice])

    // Fetch data when switching tabs
    useEffect(() => {
        if (activeTab === 'activity') {
            fetchEvents()
        } else if (activeTab === 'alerts') {
            fetchAlerts()
            fetchAlertRules()
        }
    }, [activeTab])

    const formatIdleTime = (seconds: number) => {
        if (seconds < 60) return `${Math.floor(seconds)}s`
        if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
        return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`
    }

    const getSetting = (key: string) => {
        const setting = settings.find(s => s.key === key)
        return setting ? setting.value : ''
    }

    // Render Analytics Tab
    const renderAnalytics = () => {
        // Generate sample weekly data based on current analytics
        const weeklyData = [
            { day: 'Mon', energy: (analytics?.total_energy_saved_kwh || 0) * 0.12, cost: (analytics?.total_cost_saved_rupees || 0) * 0.12, co2: (analytics?.total_co2_reduced_kg || 0) * 0.12 },
            { day: 'Tue', energy: (analytics?.total_energy_saved_kwh || 0) * 0.15, cost: (analytics?.total_cost_saved_rupees || 0) * 0.15, co2: (analytics?.total_co2_reduced_kg || 0) * 0.15 },
            { day: 'Wed', energy: (analytics?.total_energy_saved_kwh || 0) * 0.18, cost: (analytics?.total_cost_saved_rupees || 0) * 0.18, co2: (analytics?.total_co2_reduced_kg || 0) * 0.18 },
            { day: 'Thu', energy: (analytics?.total_energy_saved_kwh || 0) * 0.14, cost: (analytics?.total_cost_saved_rupees || 0) * 0.14, co2: (analytics?.total_co2_reduced_kg || 0) * 0.14 },
            { day: 'Fri', energy: (analytics?.total_energy_saved_kwh || 0) * 0.16, cost: (analytics?.total_cost_saved_rupees || 0) * 0.16, co2: (analytics?.total_co2_reduced_kg || 0) * 0.16 },
            { day: 'Sat', energy: (analytics?.total_energy_saved_kwh || 0) * 0.13, cost: (analytics?.total_cost_saved_rupees || 0) * 0.13, co2: (analytics?.total_co2_reduced_kg || 0) * 0.13 },
            { day: 'Sun', energy: (analytics?.total_energy_saved_kwh || 0) * 0.12, cost: (analytics?.total_cost_saved_rupees || 0) * 0.12, co2: (analytics?.total_co2_reduced_kg || 0) * 0.12 },
        ]

        return (
            <div className="analytics-view">
                <h1 style={{ marginBottom: 24 }}>📊 Analytics & Sustainability</h1>

                {/* Main metrics */}
                <div className="analytics-grid">
                    <div className="analytics-card green">
                        <div className="analytics-icon"><Zap size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">{analytics?.total_energy_saved_kwh || 0} kWh</div>
                            <div className="analytics-label">Total Energy Saved</div>
                        </div>
                    </div>
                    <div className="analytics-card purple">
                        <div className="analytics-icon"><DollarSign size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">₹{analytics?.total_cost_saved_rupees || 0}</div>
                            <div className="analytics-label">Total Money Saved</div>
                        </div>
                    </div>
                    <div className="analytics-card yellow">
                        <div className="analytics-icon"><Leaf size={32} /></div>
                        <div className="analytics-content">
                            <div className="analytics-value">{analytics?.total_co2_reduced_kg || 0} kg</div>
                            <div className="analytics-label">CO₂ Emissions Reduced</div>
                        </div>
                    </div>
                </div>

                {/* Today vs This Month */}
                <div className="stats-grid" style={{ marginTop: 24 }}>
                    <div className="stat-card savings">
                        <div className="stat-label"><TrendingUp size={16} /> Today's Savings</div>
                        <div className="stat-value savings">₹{analytics?.today_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            {analytics?.today_energy_saved_kwh || 0} kWh saved
                        </div>
                    </div>
                    <div className="stat-card savings">
                        <div className="stat-label"><BarChart3 size={16} /> This Month</div>
                        <div className="stat-value savings">₹{analytics?.this_month_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            {analytics?.this_month_energy_saved_kwh || 0} kWh saved
                        </div>
                    </div>
                    <div className="stat-card active">
                        <div className="stat-label"><Monitor size={16} /> Total Devices</div>
                        <div className="stat-value active">{analytics?.total_devices || 0}</div>
                    </div>
                </div>

                {/* Charts Row */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginTop: 24 }}>
                    {/* Weekly Savings Trend - Bar Chart */}
                    <div className="glass-card" style={{ padding: 24 }}>
                        <h3 style={{ marginBottom: 20 }}>📈 Weekly Savings Trend</h3>
                        <div style={{ height: 250 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={weeklyData}>
                                    <XAxis dataKey="day" stroke="var(--text-muted)" />
                                    <YAxis stroke="var(--text-muted)" />
                                    <Tooltip
                                        contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }}
                                        formatter={(value: any) => [`₹${Number(value || 0).toFixed(2)}`, 'Cost Saved'] as [string, string]}
                                    />
                                    <Bar dataKey="cost" fill="#7c3aed" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* Energy & CO2 Trends - Area Chart */}
                    <div className="glass-card" style={{ padding: 24 }}>
                        <h3 style={{ marginBottom: 20 }}>⚡ Energy & CO₂ Reduction</h3>
                        <div style={{ height: 250 }}>
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={weeklyData}>
                                    <defs>
                                        <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.4} />
                                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                                        </linearGradient>
                                        <linearGradient id="co2Grad" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#eab308" stopOpacity={0.4} />
                                            <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
                                        </linearGradient>
                                    </defs>
                                    <XAxis dataKey="day" stroke="var(--text-muted)" />
                                    <YAxis stroke="var(--text-muted)" />
                                    <Tooltip
                                        contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }}
                                    />
                                    <Area type="monotone" dataKey="energy" stroke="#22c55e" fill="url(#energyGrad)" strokeWidth={2} name="Energy (kWh)" />
                                    <Area type="monotone" dataKey="co2" stroke="#eab308" fill="url(#co2Grad)" strokeWidth={2} name="CO₂ (kg)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                </div>

                {/* Device Status Distribution */}
                <div className="glass-card" style={{ marginTop: 24, padding: 24 }}>
                    <h3 style={{ marginBottom: 20 }}>🖥️ Device Status Distribution</h3>
                    <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
                        <div style={{ width: 220, height: 220 }}>
                            <ResponsiveContainer>
                                <PieChart>
                                    <Pie
                                        data={[
                                            { name: 'Active', value: analytics?.active_devices || 0, color: '#22c55e' },
                                            { name: 'Idle', value: analytics?.idle_devices || 0, color: '#eab308' },
                                            { name: 'Offline', value: analytics?.offline_devices || 0, color: '#ef4444' }
                                        ]}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={55}
                                        outerRadius={90}
                                        dataKey="value"
                                        label={({ name, value }) => value > 0 ? `${name}: ${value}` : ''}
                                    >
                                        {[
                                            { color: '#22c55e' },
                                            { color: '#eab308' },
                                            { color: '#ef4444' }
                                        ].map((entry, index) => (
                                            <Cell key={index} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="legend" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#22c55e', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Active: {analytics?.active_devices || 0} devices</span>
                            </div>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#eab308', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Idle: {analytics?.idle_devices || 0} devices</span>
                            </div>
                            <div className="legend-item" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                <span className="dot" style={{ background: '#ef4444', width: 12, height: 12, borderRadius: '50%' }}></span>
                                <span>Offline: {analytics?.offline_devices || 0} devices</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Savings Comparison Card */}
                <div className="glass-card" style={{ marginTop: 24, padding: 24 }}>
                    <h3 style={{ marginBottom: 20 }}>💰 Savings Comparison</h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(34, 197, 94, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#22c55e' }}>
                                {analytics?.today_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh Today</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(124, 58, 237, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#7c3aed' }}>
                                {analytics?.this_month_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh This Month</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 20, background: 'rgba(234, 179, 8, 0.1)', borderRadius: 12 }}>
                            <div style={{ fontSize: '2rem', fontWeight: 700, color: '#eab308' }}>
                                {analytics?.total_energy_saved_kwh || 0}
                            </div>
                            <div style={{ color: 'var(--text-muted)', marginTop: 4 }}>kWh Total</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    // Render Settings Tab
    const renderSettings = () => (
        <div className="settings-view">
            <h1 style={{ marginBottom: 24 }}>⚙️ System Settings</h1>

            <div className="settings-grid">
                {/* Working Hours */}
                <div className="settings-card">
                    <h3>🕐 Working Hours</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Start Time</label>
                            <input
                                type="time"
                                value={getSetting('working_hours_start')}
                                onChange={(e) => updateSetting('working_hours_start', e.target.value)}
                            />
                        </div>
                        <div className="form-group">
                            <label>End Time</label>
                            <input
                                type="time"
                                value={getSetting('working_hours_end')}
                                onChange={(e) => updateSetting('working_hours_end', e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                {/* Idle Thresholds */}
                <div className="settings-card">
                    <h3>⏱️ Idle Thresholds</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Working Hours Threshold (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('working_hours_idle_threshold')}
                                onChange={(e) => updateSetting('working_hours_idle_threshold', e.target.value)}
                                min="60"
                                max="1800"
                            />
                            <small>Sleep after this idle time during working hours</small>
                        </div>
                        <div className="form-group">
                            <label>After Hours Threshold (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('after_hours_idle_threshold')}
                                onChange={(e) => updateSetting('after_hours_idle_threshold', e.target.value)}
                                min="60"
                                max="600"
                            />
                            <small>Shutdown after this idle time outside working hours</small>
                        </div>
                        <div className="form-group">
                            <label>Grace Period (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('grace_period_seconds')}
                                onChange={(e) => updateSetting('grace_period_seconds', e.target.value)}
                                min="10"
                                max="120"
                            />
                            <small>Warning popup duration before action</small>
                        </div>
                    </div>
                </div>

                {/* Energy Settings */}
                <div className="settings-card">
                    <h3>⚡ Energy Calculation</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Average PC Wattage (W)</label>
                            <input
                                type="number"
                                value={getSetting('avg_pc_wattage')}
                                onChange={(e) => updateSetting('avg_pc_wattage', e.target.value)}
                                min="50"
                                max="500"
                            />
                        </div>
                        <div className="form-group">
                            <label>Cost per kWh (₹)</label>
                            <input
                                type="number"
                                step="0.1"
                                value={getSetting('cost_per_kwh')}
                                onChange={(e) => updateSetting('cost_per_kwh', e.target.value)}
                            />
                        </div>
                        <div className="form-group">
                            <label>Carbon Intensity (kg CO₂/kWh)</label>
                            <input
                                type="number"
                                step="0.01"
                                value={getSetting('carbon_intensity')}
                                onChange={(e) => updateSetting('carbon_intensity', e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                {/* Timeouts */}
                <div className="settings-card">
                    <h3>🔌 Connection Settings</h3>
                    <div className="settings-form">
                        <div className="form-group">
                            <label>Heartbeat Timeout (seconds)</label>
                            <input
                                type="number"
                                value={getSetting('heartbeat_timeout_seconds')}
                                onChange={(e) => updateSetting('heartbeat_timeout_seconds', e.target.value)}
                                min="60"
                                max="300"
                            />
                            <small>Mark device offline after no heartbeat</small>
                        </div>
                    </div>
                </div>
            </div>

            {savingSettings && (
                <div className="toast success">
                    <Save size={18} /> Saving settings...
                </div>
            )}
        </div>
    )

    // Render Devices Page (new)
    const renderDevices = () => {
        // Filter devices based on search and filters
        const filteredDevices = devices.filter((device: any) => {
            const matchesSearch = searchQuery === '' ||
                device.hostname.toLowerCase().includes(searchQuery.toLowerCase()) ||
                device.ip_address.includes(searchQuery)
            const matchesStatus = statusFilter === 'all' || device.status === statusFilter
            // Flexible type matching (e.g., 'personal workstation' matches 'personal')
            const deviceType = (device.system_type || 'lab').toLowerCase().trim()
            const matchesType = typeFilter === 'all' || deviceType === typeFilter.toLowerCase() || deviceType.startsWith(typeFilter.toLowerCase() + ' ')
            return matchesSearch && matchesStatus && matchesType
        })

        const toggleDeviceSelection = (deviceId: string) => {
            setSelectedDevices(prev =>
                prev.includes(deviceId)
                    ? prev.filter(id => id !== deviceId)
                    : [...prev, deviceId]
            )
        }

        const toggleSelectAll = () => {
            if (selectedDevices.length === filteredDevices.length) {
                setSelectedDevices([])
            } else {
                setSelectedDevices(filteredDevices.map((d: any) => d.device_id))
            }
        }

        return (
            <div className="devices-view">
                <h1 style={{ marginBottom: 24 }}>🖥️ Device Management</h1>

                {/* Filters and Search */}
                <div className="filters-bar glass-card" style={{ padding: 16, marginBottom: 24, display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
                    <div className="search-box" style={{ position: 'relative', flex: 1, minWidth: 200 }}>
                        <Search size={18} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
                        <input
                            type="text"
                            placeholder="Search by hostname or IP..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            style={{ width: '100%', paddingLeft: 40, padding: '12px 16px 12px 40px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', fontSize: '0.875rem' }}
                        />
                    </div>
                    <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', cursor: 'pointer' }}
                    >
                        <option value="all">All Status</option>
                        <option value="active">Active</option>
                        <option value="passive">Idle</option>
                        <option value="deep_idle">Deep Idle</option>
                        <option value="offline">Offline</option>
                    </select>
                    <select
                        value={typeFilter}
                        onChange={(e) => setTypeFilter(e.target.value)}
                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', cursor: 'pointer' }}
                    >
                        <option value="all">All Types</option>
                        <option value="lab">Lab</option>
                        <option value="admin">Admin</option>
                        <option value="server">Server</option>
                        <option value="personal">Personal</option>
                    </select>
                    <button
                        className="btn btn-ghost"
                        onClick={() => fetchData()}
                        disabled={loading && activeTab === 'devices'}
                    >
                        {loading && activeTab === 'devices' ? <RefreshCw size={18} className="spin" /> : <RefreshCw size={18} />}
                        Refresh
                    </button>
                </div>

                {/* Bulk Actions */}
                {selectedDevices.length > 0 && (
                    <div className="bulk-actions glass-card" style={{ padding: 16, marginBottom: 24, display: 'flex', gap: 12, alignItems: 'center' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>{selectedDevices.length} device(s) selected</span>
                        <button
                            className="btn btn-success"
                            onClick={wakeSelectedDevices}
                            disabled={actionLoading === 'bulk-wake'}
                        >
                            {actionLoading === 'bulk-wake' ? <RefreshCw size={18} className="spin" /> : <Play size={18} />}
                            Wake Selected
                        </button>
                        <button
                            className="btn btn-danger"
                            onClick={shutdownSelectedDevices}
                            disabled={actionLoading === 'bulk-shutdown'}
                        >
                            {actionLoading === 'bulk-shutdown' ? <RefreshCw size={18} className="spin" /> : <PowerOff size={18} />}
                            Shutdown Selected
                        </button>
                        <button className="btn btn-ghost" onClick={() => setSelectedDevices([])} disabled={actionLoading !== null}>
                            Clear Selection
                        </button>
                    </div>
                )}

                {/* Devices Table */}
                <div className="glass-card" style={{ overflow: 'hidden' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border-color)' }}>
                                <th style={{ padding: 16, textAlign: 'left' }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedDevices.length === filteredDevices.length && filteredDevices.length > 0}
                                        onChange={toggleSelectAll}
                                        style={{ width: 18, height: 18, cursor: 'pointer' }}
                                    />
                                </th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>Status</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>Hostname</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>IP Address</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>Type</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>Idle Time</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>CPU</th>
                                <th style={{ padding: 16, textAlign: 'left', color: 'var(--text-muted)', fontWeight: 500, fontSize: '0.875rem' }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredDevices.map((device: any) => (
                                <tr key={device.device_id} style={{ borderBottom: '1px solid var(--border-color)', transition: 'background 0.2s' }} onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-card-hover)'} onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                                    <td style={{ padding: 16 }}>
                                        <input
                                            type="checkbox"
                                            checked={selectedDevices.includes(device.device_id)}
                                            onChange={() => toggleDeviceSelection(device.device_id)}
                                            style={{ width: 18, height: 18, cursor: 'pointer' }}
                                        />
                                    </td>
                                    <td style={{ padding: 16 }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                            <div className={`status-indicator ${device.status}`}></div>
                                            <span style={{ color: (statusColors as Record<string, string>)[device.status], fontWeight: 500 }}>{(statusLabels as Record<string, string>)[device.status]}</span>
                                        </div>
                                    </td>
                                    <td style={{ padding: 16, fontWeight: 500 }}>{device.hostname}</td>
                                    <td style={{ padding: 16, color: 'var(--text-muted)' }}>{device.ip_address}</td>
                                    <td style={{ padding: 16 }}>
                                        <span style={{ padding: '4px 8px', borderRadius: 4, background: 'var(--bg-secondary)', fontSize: '0.75rem', textTransform: 'uppercase' }}>
                                            {device.system_type || 'lab'}
                                        </span>
                                    </td>
                                    <td style={{ padding: 16 }}>{formatIdleTime(device.idle_seconds)}</td>
                                    <td style={{ padding: 16 }}>{Number(device.cpu_usage || 0).toFixed(1)}%</td>
                                    <td style={{ padding: 16 }}>
                                        <div style={{ display: 'flex', gap: 8 }}>
                                            {device.status === 'offline' ? (
                                                <button
                                                    className="btn btn-success"
                                                    style={{ padding: '8px 12px', fontSize: '0.75rem' }}
                                                    disabled={actionLoading === `wake-${device.device_id}`}
                                                    onClick={async () => {
                                                        setActionLoading(`wake-${device.device_id}`)
                                                        try {
                                                            const res = await fetch(`${API_URL}/api/devices/${device.device_id}/wake`, { method: 'POST' })
                                                            if (res.ok) {
                                                                showToast(`Wake packet sent to ${device.hostname}`, 'success')
                                                                await Promise.all([fetchData(), fetchEvents()])
                                                            } else {
                                                                showToast('Failed to send wake packet', 'error')
                                                            }
                                                        } catch {
                                                            showToast('Network error', 'error')
                                                        }
                                                        setActionLoading(null)
                                                    }}
                                                >
                                                    {actionLoading === `wake-${device.device_id}` ? <RefreshCw size={14} className="spin" /> : <Play size={14} />}
                                                    Wake
                                                </button>
                                            ) : (
                                                <button
                                                    className="btn btn-ghost"
                                                    style={{ padding: '8px 12px', fontSize: '0.75rem' }}
                                                    disabled={actionLoading === `shutdown-${device.device_id}`}
                                                    onClick={async () => {
                                                        setActionLoading(`shutdown-${device.device_id}`)
                                                        try {
                                                            const res = await fetch(`${API_URL}/api/devices/${device.device_id}/command`, {
                                                                method: 'POST',
                                                                headers: { 'Content-Type': 'application/json' },
                                                                body: JSON.stringify({ command: 'SHUTDOWN', message: 'Manual shutdown' })
                                                            })
                                                            if (res.ok) {
                                                                showToast(`Shutdown command sent to ${device.hostname}`, 'success')
                                                                await Promise.all([fetchData(), fetchEvents()])
                                                            } else {
                                                                showToast('Failed to send shutdown command', 'error')
                                                            }
                                                        } catch {
                                                            showToast('Network error', 'error')
                                                        }
                                                        setActionLoading(null)
                                                    }}
                                                >
                                                    {actionLoading === `shutdown-${device.device_id}` ? <RefreshCw size={14} className="spin" /> : <PowerOff size={14} />}
                                                    Shutdown
                                                </button>
                                            )}
                                            <button
                                                className="btn btn-ghost"
                                                style={{ padding: '8px 12px', fontSize: '0.75rem' }}
                                                onClick={() => {
                                                    setSelectedDevice(device.device_id)
                                                    fetchDeviceDetail(device.device_id)
                                                }}
                                                disabled={actionLoading === `detail-${device.device_id}`}
                                            >
                                                {actionLoading === `detail-${device.device_id}` ? <RefreshCw size={14} className="spin" /> : 'Details'}
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {filteredDevices.length === 0 && (
                        <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)' }}>
                            <Monitor size={48} style={{ opacity: 0.3, marginBottom: 16 }} />
                            <p>No devices match your filters</p>
                        </div>
                    )}
                </div>
            </div>
        )
    }

    // Render Activity Page (new)
    const renderActivity = () => {
        const filteredEvents = events.filter((event: any) =>
            eventTypeFilter === 'all' || event.event_type === eventTypeFilter
        )

        const getEventIcon = (type: string) => {
            switch (type) {
                case 'SHUTDOWN': return <PowerOff size={18} style={{ color: '#ef4444' }} />
                case 'HIBERNATE': return <Moon size={18} style={{ color: '#3b82f6' }} />
                case 'SLEEP': return <Moon size={18} style={{ color: '#eab308' }} />
                case 'WAKE': return <Sun size={18} style={{ color: '#22c55e' }} />
                case 'WOL': return <Zap size={18} style={{ color: '#6366f1' }} />
                default: return <Activity size={18} style={{ color: 'var(--text-muted)' }} />
            }
        }

        const formatTimestamp = (ts: string) => {
            // Backend sends UTC naive time (e.g. "2023-12-29T06:00:00")
            // Append 'Z' to treat it as UTC so browser converts to local time
            const date = new Date(ts.endsWith('Z') ? ts : ts + 'Z')
            return date.toLocaleString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            })
        }

        return (
            <div className="activity-view">
                <h1 style={{ marginBottom: 24 }}>📋 Activity Logs</h1>

                {/* Filters */}
                <div className="filters-bar glass-card" style={{ padding: 16, marginBottom: 24, display: 'flex', gap: 16, alignItems: 'center' }}>
                    <Filter size={18} style={{ color: 'var(--text-muted)' }} />
                    <select
                        value={eventTypeFilter}
                        onChange={(e) => setEventTypeFilter(e.target.value)}
                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', cursor: 'pointer' }}
                    >
                        <option value="all">All Events</option>
                        <option value="SHUTDOWN">Shutdown</option>
                        <option value="HIBERNATE">Hibernate</option>
                        <option value="SLEEP">Sleep</option>
                        <option value="WAKE">Wake</option>
                        <option value="WOL">Wake-on-LAN</option>
                    </select>
                    <button
                        className="btn btn-ghost"
                        onClick={fetchEvents}
                        disabled={actionLoading === 'refresh-events'}
                    >
                        <RefreshCw size={18} className={actionLoading === 'refresh-events' ? 'spin' : ''} />
                        {actionLoading === 'refresh-events' ? 'Refreshing...' : 'Refresh'}
                    </button>
                    <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                        Showing {filteredEvents.length} events
                    </span>
                </div>

                {/* Events Timeline */}
                <div className="glass-card" style={{ padding: 24 }}>
                    {filteredEvents.length === 0 ? (
                        <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-muted)' }}>
                            <Clock size={48} style={{ opacity: 0.3, marginBottom: 16 }} />
                            <p>No power events recorded yet</p>
                        </div>
                    ) : (
                        <div className="timeline" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                            {filteredEvents.map((event: any) => (
                                <div key={event.id} className="timeline-event" style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, background: 'var(--bg-secondary)', borderRadius: 12, borderLeft: '3px solid var(--accent-primary)' }}>
                                    <div className="event-icon" style={{ width: 40, height: 40, borderRadius: 8, background: 'var(--bg-card)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                        {getEventIcon(event.event_type)}
                                    </div>
                                    <div className="event-info" style={{ flex: 1 }}>
                                        <div style={{ fontWeight: 600, marginBottom: 4 }}>
                                            {event.event_type} - {event.device_hostname || 'Unknown Device'}
                                        </div>
                                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                                            Triggered by: {event.triggered_by} • IP: {event.device_ip || 'N/A'}
                                        </div>
                                    </div>
                                    <div className="event-time" style={{ color: 'var(--text-muted)', fontSize: '0.875rem', textAlign: 'right', display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                                            <Clock size={14} />
                                            {formatTimestamp(event.timestamp)}
                                        </div>
                                        <button
                                            className="btn btn-ghost"
                                            style={{ padding: '4px 8px', color: '#ef4444', height: 'auto', minHeight: 'unset' }}
                                            onClick={() => deleteEvent(event.id)}
                                            disabled={actionLoading === `del-event-${event.id}`}
                                            title="Delete log"
                                        >
                                            {actionLoading === `del-event-${event.id}` ? <RefreshCw size={14} className="spin" /> : <Trash2 size={14} />}
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        )
    }

    // Render Alerts Page (new)
    const renderAlerts = () => {
        const getSeverityColor = (severity: string) => {
            switch (severity) {
                case 'critical': return '#ef4444'
                case 'warning': return '#eab308'
                case 'info': return '#3b82f6'
                default: return 'var(--text-muted)'
            }
        }

        return (
            <div className="alerts-view">
                <h1 style={{ marginBottom: 24 }}>
                    🔔 Alerts & Notifications
                    {unacknowledgedCount > 0 && (
                        <span style={{ marginLeft: 12, padding: '4px 12px', background: '#ef4444', borderRadius: 12, fontSize: '0.875rem', fontWeight: 500 }}>
                            {unacknowledgedCount} new
                        </span>
                    )}
                </h1>

                {/* Tab Switcher */}
                <div className="tab-switcher" style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
                    <button
                        className={`btn ${alertsTab === 'alerts' ? 'btn-primary' : 'btn-ghost'}`}
                        onClick={() => setAlertsTab('alerts')}
                    >
                        <Bell size={18} /> Active Alerts ({alerts.length})
                    </button>
                    <button
                        className={`btn ${alertsTab === 'rules' ? 'btn-primary' : 'btn-ghost'}`}
                        onClick={() => setAlertsTab('rules')}
                    >
                        <Settings size={18} /> Alert Rules ({alertRules.length})
                    </button>
                </div>

                {alertsTab === 'alerts' ? (
                    <div className="alerts-list glass-card" style={{ padding: 24 }}>
                        {alerts.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-muted)' }}>
                                <CheckCircle size={48} style={{ opacity: 0.3, marginBottom: 16, color: '#22c55e' }} />
                                <p>No alerts - everything looks good! 🎉</p>
                            </div>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                                {alerts.map((alert: any) => (
                                    <div
                                        key={alert.id}
                                        className="alert-card"
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 16,
                                            padding: 16,
                                            background: 'var(--bg-secondary)',
                                            borderRadius: 12,
                                            borderLeft: `4px solid ${getSeverityColor(alert.severity)}`,
                                            opacity: alert.is_acknowledged ? 0.6 : 1
                                        }}
                                    >
                                        <div style={{ width: 40, height: 40, borderRadius: 8, background: `${getSeverityColor(alert.severity)}20`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                            <AlertTriangle size={20} style={{ color: getSeverityColor(alert.severity) }} />
                                        </div>
                                        <div style={{ flex: 1 }}>
                                            <div style={{ fontWeight: 600, marginBottom: 4, display: 'flex', alignItems: 'center', gap: 8 }}>
                                                {alert.message}
                                                <span style={{ padding: '2px 8px', borderRadius: 4, background: `${getSeverityColor(alert.severity)}20`, color: getSeverityColor(alert.severity), fontSize: '0.7rem', textTransform: 'uppercase' }}>
                                                    {alert.severity}
                                                </span>
                                                {alert.is_acknowledged && (
                                                    <span style={{ padding: '2px 8px', borderRadius: 4, background: 'var(--bg-card)', color: 'var(--text-muted)', fontSize: '0.7rem' }}>
                                                        Acknowledged
                                                    </span>
                                                )}
                                            </div>
                                            <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                                                {alert.device_hostname && `Device: ${alert.device_hostname} • `}
                                                Type: {alert.alert_type}
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', gap: 8 }}>
                                            {!alert.is_acknowledged && (
                                                <button className="btn btn-ghost" style={{ padding: '8px 12px' }} onClick={() => acknowledgeAlert(alert.id)} title="Acknowledge">
                                                    <CheckCircle size={18} />
                                                </button>
                                            )}
                                            <button className="btn btn-ghost" style={{ padding: '8px 12px', color: '#ef4444' }} onClick={() => deleteAlert(alert.id)} title="Delete">
                                                <Trash2 size={18} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                ) : (
                    <div className="alert-rules glass-card" style={{ padding: 24 }}>
                        <div style={{ marginBottom: 24, borderBottom: '1px solid var(--border-color)', paddingBottom: 24 }}>
                            <h3 style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                                <Plus size={20} /> Create New Trigger Rule
                            </h3>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 120px auto', gap: 12, alignItems: 'end' }}>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>RULE NAME</label>
                                    <input
                                        type="text"
                                        placeholder="e.g. Server Offline Alert"
                                        value={newRule.name}
                                        onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
                                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
                                    />
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>TYPE</label>
                                    <select
                                        value={newRule.rule_type}
                                        onChange={(e) => setNewRule({ ...newRule, rule_type: e.target.value })}
                                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)', cursor: 'pointer' }}
                                    >
                                        <option value="offline_timeout">Offline Timeout</option>
                                        <option value="idle_timeout">Idle Timeout</option>
                                        <option value="high_cpu">High CPU Usage</option>
                                        <option value="high_ram">High RAM Usage</option>
                                    </select>
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                    <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: 600 }}>THRESHOLD</label>
                                    <input
                                        type="number"
                                        value={newRule.threshold_value}
                                        onChange={(e) => setNewRule({ ...newRule, threshold_value: parseInt(e.target.value) || 0 })}
                                        style={{ padding: '12px 16px', background: 'var(--bg-secondary)', border: '1px solid var(--border-color)', borderRadius: 8, color: 'var(--text-primary)' }}
                                    />
                                </div>
                                <button
                                    className="btn btn-primary"
                                    style={{ height: 46 }}
                                    onClick={createAlertRule}
                                    disabled={actionLoading === 'create-rule'}
                                >
                                    {actionLoading === 'create-rule' ? <RefreshCw size={18} className="spin" /> : <Plus size={18} />}
                                    Create Rule
                                </button>
                            </div>
                        </div>

                        <h3 style={{ marginBottom: 16 }}>Configured Rules</h3>
                        {alertRules.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>
                                <p>No rules configured yet.</p>
                            </div>
                        ) : (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                                {alertRules.map((rule: any) => (
                                    <div
                                        key={rule.id}
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 16,
                                            padding: 16,
                                            background: 'var(--bg-secondary)',
                                            borderRadius: 12,
                                            border: '1px solid var(--border-color)',
                                            opacity: rule.is_enabled ? 1 : 0.6
                                        }}
                                    >
                                        <div style={{ flex: 1 }}>
                                            <div style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                                                {rule.name}
                                                {!rule.is_enabled && <span style={{ fontSize: '0.7rem', background: 'var(--bg-card)', padding: '2px 6px', borderRadius: 4, color: 'var(--text-muted)' }}>DISABLED</span>}
                                            </div>
                                            <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginTop: 4 }}>
                                                {rule.rule_type === 'offline_timeout' && `Triggers if device is offline for > ${rule.threshold_value}s`}
                                                {rule.rule_type === 'idle_timeout' && `Triggers if device is idle for > ${rule.threshold_value}s`}
                                                {rule.rule_type === 'high_cpu' && `Triggers if CPU > ${rule.threshold_value}%`}
                                                {rule.rule_type === 'high_ram' && `Triggers if RAM > ${rule.threshold_value}%`}
                                            </div>
                                        </div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                                            <button
                                                className="btn btn-ghost"
                                                onClick={() => toggleAlertRule(rule.id, rule.is_enabled)}
                                                style={{ color: rule.is_enabled ? '#22c55e' : 'var(--text-muted)', padding: 4 }}
                                                disabled={actionLoading === `toggle-rule-${rule.id}`}
                                            >
                                                {actionLoading === `toggle-rule-${rule.id}` ? <RefreshCw size={24} className="spin" />
                                                    : rule.is_enabled ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
                                            </button>
                                            <button
                                                className="btn btn-ghost"
                                                style={{ color: '#ef4444', padding: 8 }}
                                                onClick={() => deleteAlertRule(rule.id)}
                                                disabled={actionLoading === `del-rule-${rule.id}`}
                                            >
                                                {actionLoading === `del-rule-${rule.id}` ? <RefreshCw size={18} className="spin" /> : <Trash2 size={18} />}
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        )
    }

    // Render Dashboard (default)
    const renderDashboard = () => (
        <>
            <header className="header">
                <div>
                    <h1>Power Management Dashboard</h1>
                    <p style={{ color: 'var(--text-muted)', marginTop: 4 }}>
                        Monitor and control lab computers
                    </p>
                </div>
                <div className="action-buttons">
                    <a
                        href="/Smart Power Sync.zip"
                        download="Smart Power Sync.zip"
                        className="btn btn-ghost"
                        style={{ background: 'rgba(99, 102, 241, 0.1)', color: '#6366f1', borderColor: 'rgba(99, 102, 241, 0.2)' }}
                    >
                        <Download size={18} />
                        Download Software
                    </a>
                    <button
                        className="btn btn-ghost"
                        disabled={actionLoading !== null}
                        onClick={async () => {
                            setActionLoading('refresh');
                            try {
                                await fetchData();
                                showToast('Data refreshed successfully', 'success');
                            } catch {
                                showToast('Failed to refresh data', 'error');
                            }
                            setActionLoading(null);
                        }}
                    >
                        <RefreshCw size={18} className={actionLoading === 'refresh' ? 'spin' : ''} />
                        {actionLoading === 'refresh' ? 'Refreshing...' : 'Refresh'}
                    </button>
                    <button
                        className="btn btn-success"
                        disabled={actionLoading !== null}
                        onClick={async () => {
                            setActionLoading('wake');
                            try {
                                const res = await fetch(`${API_URL}/api/devices/wake-all`, { method: 'POST' });
                                if (res.ok) {
                                    showToast('Wake command sent to all devices!', 'success');
                                } else {
                                    showToast('Failed to send wake command', 'error');
                                }
                                await Promise.all([fetchData(), fetchEvents()]);
                            } catch {
                                showToast('Network error - could not reach server', 'error');
                            }
                            setActionLoading(null);
                        }}
                    >
                        <Play size={18} /> {actionLoading === 'wake' ? 'Waking...' : 'Wake All'}
                    </button>
                    <button
                        className="btn btn-primary"
                        style={{ background: '#3b82f6', border: 'none' }}
                        disabled={actionLoading !== null}
                        onClick={async () => {
                            setActionLoading('hibernate');
                            try {
                                const res = await fetch(`${API_URL}/api/devices/hibernate-all-idle`, { method: 'POST' });
                                if (res.ok) {
                                    const data = await res.json();
                                    if (data.count > 0) {
                                        showToast(`Hibernation command sent to ${data.count} idle devices!`, 'success');
                                    } else {
                                        showToast('No deeply idle devices found (>20m idle)', 'info');
                                    }
                                } else {
                                    showToast('Failed to send hibernation command', 'error');
                                }
                                await Promise.all([fetchData(), fetchEvents()]);
                            } catch {
                                showToast('Network error - could not reach server', 'error');
                            }
                            setActionLoading(null);
                        }}
                    >
                        <Moon size={18} /> {actionLoading === 'hibernate' ? 'Hibernating...' : 'Hibernate Idle'}
                    </button>
                    <button
                        className="btn btn-primary"
                        style={{ background: '#6366f1', border: 'none' }}
                        disabled={actionLoading !== null}
                        onClick={async () => {
                            setActionLoading('sleep');
                            try {
                                const res = await fetch(`${API_URL}/api/devices/sleep-all-idle`, { method: 'POST' });
                                if (res.ok) {
                                    const data = await res.json();
                                    if (data.count > 0) {
                                        showToast(`Sleep command sent to ${data.count} idle devices!`, 'success');
                                    } else {
                                        showToast('No deeply idle devices found (>20m idle)', 'info');
                                    }
                                } else {
                                    showToast('Failed to send sleep command', 'error');
                                }
                                await Promise.all([fetchData(), fetchEvents()]);
                            } catch {
                                showToast('Network error - could not reach server', 'error');
                            }
                            setActionLoading(null);
                        }}
                    >
                        <Moon size={18} style={{ opacity: 0.7 }} /> {actionLoading === 'sleep' ? 'Sleeping...' : 'Sleep Idle'}
                    </button>
                    <button
                        className="btn btn-danger"
                        disabled={actionLoading !== null}
                        onClick={async () => {
                            setActionLoading('shutdown');
                            try {
                                const res = await fetch(`${API_URL}/api/devices/shutdown-all-idle`, { method: 'POST' });
                                if (res.ok) {
                                    const data = await res.json();
                                    if (data.count > 0) {
                                        showToast(`Shutdown command sent to ${data.count} idle devices!`, 'success');
                                    } else {
                                        showToast('No deeply idle devices found (>20m idle)', 'info');
                                    }
                                } else {
                                    showToast('Failed to send shutdown command', 'error');
                                }
                                await Promise.all([fetchData(), fetchEvents()]);
                            } catch {
                                showToast('Network error - could not reach server', 'error');
                            }
                            setActionLoading(null);
                        }}
                    >
                        <PowerOff size={18} /> {actionLoading === 'shutdown' ? 'Shutting down...' : 'Shutdown Idle'}
                    </button>
                </div>
            </header>

            <div className="power-state-summary glass-card" style={{ marginBottom: 24, padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', gap: 24 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#22c55e' }}></div>
                        <span style={{ fontWeight: 600 }}>{devices.filter(d => d.last_power_state === 'ACTIVE' && d.status !== 'offline').length} Active</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#eab308' }}></div>
                        <span style={{ fontWeight: 600 }}>{devices.filter(d => d.status === 'passive' || d.status === 'deep_idle').length} Idle</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#3b82f6' }}></div>
                        <span style={{ fontWeight: 600 }}>{devices.filter(d => d.last_power_state === 'SLEEP').length} Sleeping</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#ef4444' }}></div>
                        <span style={{ fontWeight: 600 }}>{devices.filter(d => d.last_power_state === 'SHUTDOWN' || d.status === 'offline').length} Shutdown</span>
                    </div>
                </div>
                <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem', fontWeight: 500 }}>
                    System Power Overview
                </div>
            </div>

            <div className="stats-grid">
                <div className="stat-card active">
                    <div className="stat-label"><Activity size={16} /> Active Devices</div>
                    <div className="stat-value active">{analytics?.active_devices || 0}</div>
                </div>
                <div className="stat-card idle">
                    <div className="stat-label"><AlertTriangle size={16} /> Idle Devices</div>
                    <div className="stat-value idle">{analytics?.idle_devices || 0}</div>
                </div>
                <div className="stat-card offline">
                    <div className="stat-label"><WifiOff size={16} /> Offline Devices</div>
                    <div className="stat-value offline">{analytics?.offline_devices || 0}</div>
                </div>
                <div className="stat-card savings">
                    <div className="stat-label"><Zap size={16} /> Total Savings</div>
                    <div className="stat-value savings">₹{analytics?.total_cost_saved_rupees || 0}</div>
                </div>
            </div>

            <div className="sustainability-banner glass-card" style={{ marginBottom: 24, padding: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-around', textAlign: 'center' }}>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--status-active)' }}>{analytics?.total_energy_saved_kwh || 0} kWh</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Energy Saved</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--accent-primary)' }}>₹{analytics?.total_cost_saved_rupees || 0}</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Money Saved</div>
                    </div>
                    <div>
                        <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--status-idle)' }}>{analytics?.total_co2_reduced_kg || 0} kg</div>
                        <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>CO₂ Reduced</div>
                    </div>
                </div>
            </div>

            {/* All Device Categories */}
            {(() => {
                // Category definitions with icons and colors
                const categories = [
                    { type: 'admin', label: '👑 Admin Systems', color: '#7c3aed', noHibernate: true },
                    { type: 'server', label: '🌐 Server Systems', color: '#3b82f6', noHibernate: false },
                    { type: 'lab', label: '🖥️ Lab Computers', color: '#22c55e', noHibernate: false },
                    { type: 'personal', label: '💻 Personal Workstations', color: '#f97316', noHibernate: false },
                    { type: 'network', label: '🔗 Network Devices', color: '#06b6d4', noHibernate: false },
                ]

                // Sort function: active first, then idle, then offline
                const statusPriority: Record<string, number> = { active: 0, passive: 1, deep_idle: 2, offline: 3 }
                const sortByStatus = (a: any, b: any) => ((statusPriority as any)[a.status] || 3) - ((statusPriority as any)[b.status] || 3)

                // Group devices by category with mutual exclusivity (Priority: Admin > Server > Personal > Network > Lab)
                const getDevicesByType = (targetType: string) => {
                    return devices
                        .filter(d => {
                            const deviceType = (d.system_type || 'lab').toLowerCase().trim();

                            // Determine the single best category for this device
                            let assignedType = 'lab';
                            if (deviceType.includes('admin')) assignedType = 'admin';
                            else if (deviceType.includes('server')) assignedType = 'server';
                            else if (deviceType.includes('personal')) assignedType = 'personal';
                            else if (deviceType.includes('network')) assignedType = 'network';

                            return assignedType === targetType.toLowerCase();
                        })
                        .sort(sortByStatus)
                }

                // Render a device card
                const renderDeviceCard = (device: any, category: any) => {
                    const isAdmin = device.system_type === 'admin';
                    const powerState = device.last_power_state || 'ACTIVE';

                    // State-based icons and colors
                    const stateIcon = powerState === 'HIBERNATE' ? <Moon size={14} /> :
                        powerState === 'SLEEP' ? <Moon size={14} style={{ opacity: 0.7 }} /> :
                            powerState === 'SHUTDOWN' ? <Power size={14} /> :
                                device.status === 'offline' ? <WifiOff size={14} /> : <Zap size={14} />;

                    const stateColor = powerState === 'HIBERNATE' ? '#3b82f6' :
                        powerState === 'SLEEP' ? '#6366f1' :
                            powerState === 'SHUTDOWN' ? '#ef4444' :
                                device.status === 'offline' ? '#94a3b8' : '#22c55e';

                    return (
                        <div
                            key={device.device_id}
                            className={`device-card ${device.status} ${isAdmin ? 'admin-highlight' : ''}`}
                            onClick={() => {
                                setSelectedDevice(device.device_id)
                                fetchDeviceDetail(device.device_id)
                            }}
                            style={{
                                borderLeft: isAdmin ? `4px solid ${category.color}` : `3px solid ${category.color}`,
                                boxShadow: isAdmin ? `0 0 15px ${category.color}33` : 'none',
                                transform: isAdmin ? 'scale(1.02)' : 'none'
                            }}
                        >
                            <div className="device-header">
                                <div className={`status-indicator ${device.status}`} style={{ background: stateColor }}></div>
                                <div style={{ flex: 1 }}>
                                    <div className="device-name" style={{ display: 'flex', alignItems: 'center', gap: 6, fontWeight: isAdmin ? 700 : 600 }}>
                                        {device.hostname}
                                        {isAdmin && <span title="Primary Control System">👑</span>}
                                        <span style={{
                                            fontSize: '0.6rem',
                                            background: isAdmin ? 'linear-gradient(45deg, #7c3aed, #db2777)' : category.color,
                                            color: 'white',
                                            padding: '2px 6px',
                                            borderRadius: 4,
                                            textTransform: 'uppercase',
                                            fontWeight: 800
                                        }}>
                                            {device.system_type || 'lab'}
                                        </span>
                                    </div>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
                                        <div style={{ color: stateColor, display: 'flex', alignItems: 'center', gap: 4, fontSize: '0.75rem', fontWeight: 600 }}>
                                            {stateIcon} {powerState === 'HIBERNATE' ? 'HIBERNATED' : powerState === 'SLEEP' ? 'SLEEPING' : powerState}
                                        </div>
                                        <div className="device-ip">• {device.ip_address}</div>
                                    </div>
                                </div>
                            </div>
                            <div className="device-metrics">
                                <div className="metric">
                                    <div className="metric-label">Status</div>
                                    <div className="metric-value" style={{ color: (statusColors as Record<string, string>)[device.status] }}>{(statusLabels as Record<string, string>)[device.status]}</div>
                                </div>
                                <div className="metric">
                                    <div className="metric-label">Idle Time</div>
                                    <div className="metric-value">
                                        {formatIdleTime(device.idle_seconds || 0)}
                                    </div>
                                </div>
                                <div className="metric">
                                    <div className="metric-label">CPU Usage</div>
                                    <div className="metric-value">{Number(device.cpu_usage || 0).toFixed(1)}%</div>
                                </div>
                                <div className="metric">
                                    <div className="metric-label">RAM</div>
                                    <div className="metric-value">
                                        {Number(device.ram_usage || 0).toFixed(0)}%
                                        <span style={{ fontSize: '0.7rem', opacity: 0.6, marginLeft: 4 }}>
                                            ({Math.round(device.ram_total_gb || 0)}GB)
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                }

                return (
                    <>
                        {loading ? (
                            <div style={{ display: 'flex', justifyContent: 'center', padding: 60 }}>
                                <div className="loading-spinner"></div>
                            </div>
                        ) : (
                            <>
                                {categories.map(category => {
                                    const categoryDevices = getDevicesByType(category.type)
                                    if (categoryDevices.length === 0) return null

                                    return (
                                        <div key={category.type} style={{ marginBottom: 32 }}>
                                            <h2 style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                                                {category.label}
                                                <span style={{ fontSize: '0.8rem', background: 'var(--bg-card)', padding: '2px 8px', borderRadius: 12, color: 'var(--text-muted)', fontWeight: 400 }}>
                                                    {categoryDevices.length}
                                                </span>
                                                {category.noHibernate && (
                                                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 400, marginLeft: 4 }}>
                                                        (No auto-hibernation)
                                                    </span>
                                                )}
                                            </h2>
                                            <div className="device-grid">
                                                {categoryDevices.map(device => renderDeviceCard(device, category))}
                                            </div>
                                        </div>
                                    )
                                })}

                                {devices.length === 0 && (
                                    <div style={{ textAlign: 'center', padding: 60, color: 'var(--text-muted)' }}>
                                        <Monitor size={64} style={{ opacity: 0.3, marginBottom: 16 }} />
                                        <h3>No devices connected</h3>
                                        <p>Start the agent on computers to see them here</p>
                                    </div>
                                )}
                            </>
                        )}
                    </>
                )
            })()}
        </>
    )

    return (
        <div className="app-container">
            <aside className="sidebar">
                <div className="logo">
                    <div className="logo-icon">⚡</div>
                    <span className="logo-text">PowerSync</span>
                </div>

                <nav className="nav-menu">
                    <div className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>
                        <Monitor size={20} /><span>Dashboard</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'devices' ? 'active' : ''}`} onClick={() => setActiveTab('devices')}>
                        <List size={20} /><span>Devices</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'activity' ? 'active' : ''}`} onClick={() => setActiveTab('activity')}>
                        <Clock size={20} /><span>Activity</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => setActiveTab('analytics')}>
                        <BarChart3 size={20} /><span>Analytics</span>
                    </div>
                    <div className={`nav-item ${activeTab === 'alerts' ? 'active' : ''}`} onClick={() => setActiveTab('alerts')}>
                        <Bell size={20} /><span>Alerts</span>
                        {unacknowledgedCount > 0 && <span style={{ marginLeft: 'auto', background: '#ef4444', padding: '2px 8px', borderRadius: 10, fontSize: '0.75rem' }}>{unacknowledgedCount}</span>}
                    </div>
                    <div className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>
                        <Settings size={20} /><span>Settings</span>
                    </div>
                </nav>

                <div className="sidebar-stats">
                    <h4 style={{ color: 'var(--text-muted)', marginBottom: 12, fontSize: '0.75rem', textTransform: 'uppercase' }}>Quick Stats</h4>
                    {analytics && (
                        <>
                            <div className="mini-stat"><span className="mini-stat-label">Energy Saved Today</span><span className="mini-stat-value">{analytics.today_energy_saved_kwh} kWh</span></div>
                            <div className="mini-stat"><span className="mini-stat-label">Cost Saved Today</span><span className="mini-stat-value">₹{analytics.today_cost_saved_rupees}</span></div>
                        </>
                    )}
                </div>
            </aside>

            <main className="main-content">
                {activeTab === 'dashboard' && renderDashboard()}
                {activeTab === 'devices' && renderDevices()}
                {activeTab === 'activity' && renderActivity()}
                {activeTab === 'analytics' && renderAnalytics()}
                {activeTab === 'alerts' && renderAlerts()}
                {activeTab === 'settings' && renderSettings()}
            </main>

            <div className={`backdrop ${selectedDevice ? 'visible' : ''}`} onClick={() => setSelectedDevice(null)} />

            <aside className={`detail-panel ${selectedDevice ? 'open' : ''}`}>
                {(selectedDevice && actionLoading === `detail-${selectedDevice}`) ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', gap: 16 }}>
                        <RefreshCw size={40} className="spin" style={{ color: 'var(--accent-primary)' }} />
                        <span style={{ color: 'var(--text-muted)' }}>Loading device details...</span>
                    </div>
                ) : deviceDetail && (
                    <>
                        <div className="detail-header">
                            <div>
                                <h2>{deviceDetail.hostname}</h2>
                                <div style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{deviceDetail.ip_address}</div>
                            </div>
                            <button className="btn btn-ghost" onClick={() => setSelectedDevice(null)}><X size={20} /></button>
                        </div>
                        <div className="detail-content">
                            <div className="detail-section">
                                <h4>Impact This Device</h4>
                                <div className="impact-badges">
                                    <div className="impact-badge"><div className="impact-value">{deviceDetail.energy_saved_kwh}</div><div className="impact-label">kWh Saved</div></div>
                                    <div className="impact-badge"><div className="impact-value">₹{deviceDetail.cost_saved_rupees}</div><div className="impact-label">Money Saved</div></div>
                                    <div className="impact-badge"><div className="impact-value">{deviceDetail.co2_reduced_kg}</div><div className="impact-label">kg CO₂</div></div>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>CPU Usage (Last Hour)</h4>
                                <div className="chart-container">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={deviceDetail.recent_cpu_history}>
                                            <defs><linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} /><stop offset="95%" stopColor="#6366f1" stopOpacity={0} /></linearGradient></defs>
                                            <XAxis dataKey="timestamp" hide /><YAxis domain={[0, 100]} hide />
                                            <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-color)', borderRadius: 8 }} formatter={(value: any) => [`${Number(value || 0).toFixed(1)}%`, 'CPU'] as [string, string]} />
                                            <Area type="monotone" dataKey="value" stroke="#6366f1" fill="url(#cpuGradient)" strokeWidth={2} />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>System Specifications</h4>
                                <div className="specs-list">
                                    <div className="spec-item"><span className="spec-label">Operating System</span><span className="spec-value">{deviceDetail.os_name} {deviceDetail.os_version}</span></div>
                                    <div className="spec-item"><span className="spec-label">Processor</span><span className="spec-value">{deviceDetail.cpu_model}</span></div>
                                    <div className="spec-item"><span className="spec-label">RAM</span><span className="spec-value">{deviceDetail.ram_total_gb} GB</span></div>
                                    <div className="spec-item"><span className="spec-label">MAC Address</span><span className="spec-value">{deviceDetail.mac_address}</span></div>
                                </div>
                            </div>
                            <div className="detail-section">
                                <h4>Quick Actions</h4>
                                <div className="action-buttons">
                                    {deviceDetail.status === 'offline' ? (
                                        <button
                                            className="btn btn-success"
                                            disabled={actionLoading === `wake-${deviceDetail.device_id}`}
                                            onClick={() => wakeDevice(deviceDetail.device_id, deviceDetail.hostname)}
                                        >
                                            {actionLoading === `wake-${deviceDetail.device_id}` ? <RefreshCw size={18} className="spin" /> : <Play size={18} />}
                                            Wake Up (WOL)
                                        </button>
                                    ) : (
                                        <>
                                            <button
                                                className="btn btn-primary"
                                                disabled={actionLoading === `hibernate-${deviceDetail.device_id}`}
                                                onClick={() => sendCommand(deviceDetail.device_id, 'HIBERNATE', 'Manual hibernate', deviceDetail.hostname)}
                                            >
                                                {actionLoading === `hibernate-${deviceDetail.device_id}` ? <RefreshCw size={18} className="spin" /> : <Moon size={18} />}
                                                Hibernate
                                            </button>
                                            <button
                                                className="btn btn-primary"
                                                style={{ background: '#6366f1' }}
                                                disabled={actionLoading === `sleep-${deviceDetail.device_id}`}
                                                onClick={() => sendCommand(deviceDetail.device_id, 'SLEEP', 'Manual sleep', deviceDetail.hostname)}
                                            >
                                                {actionLoading === `sleep-${deviceDetail.device_id}` ? <RefreshCw size={18} className="spin" /> : <Moon size={18} style={{ opacity: 0.7 }} />}
                                                Sleep
                                            </button>
                                            <button
                                                className="btn btn-danger"
                                                disabled={actionLoading === `shutdown-${deviceDetail.device_id}`}
                                                onClick={() => sendCommand(deviceDetail.device_id, 'SHUTDOWN', 'Manual shutdown', deviceDetail.hostname)}
                                            >
                                                {actionLoading === `shutdown-${deviceDetail.device_id}` ? <RefreshCw size={18} className="spin" /> : <PowerOff size={18} />}
                                                Shutdown
                                            </button>
                                        </>
                                    )}
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </aside>

            {/* Toast Notification */}
            {toast && (
                <div style={{
                    position: 'fixed',
                    top: 20,
                    right: 20,
                    padding: '16px 24px',
                    borderRadius: '12px',
                    background: toast.type === 'success' ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
                        : toast.type === 'error' ? 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'
                            : 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                    color: 'white',
                    fontWeight: 500,
                    boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
                    zIndex: 9999,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '10px',
                    animation: 'slideIn 0.3s ease-out'
                }}>
                    {toast.type === 'success' && <CheckCircle size={20} />}
                    {toast.type === 'error' && <AlertTriangle size={20} />}
                    {toast.type === 'info' && <RefreshCw size={20} />}
                    {toast.message}
                </div>
            )}
        </div>
    )
}

export default App
