Set WshShell = CreateObject("WScript.Shell") 
WshShell.CurrentDirectory = "c:\Users\Lenovo\Desktop\smart power execution\agent" 
WshShell.Run "pythonw agent.py", 0, False 
