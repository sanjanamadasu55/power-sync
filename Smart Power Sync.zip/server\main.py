"""
Smart Power Management System - Central API Server
FastAPI application for managing lab computer power states
"""
from fastapi import FastAPI, Depends, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List
import json

from database import get_db, init_db
from models import Device, Heartbeat, PowerEvent, Settings, NetworkSwitch, Alert, AlertRule
from schemas import (
    HeartbeatRequest, HeartbeatResponse, CommandType,
    DeviceResponse, DeviceDetailResponse, DeviceListResponse,
    SendCommandRequest, AnalyticsResponse, SettingsResponse,
    SettingItem, UpdateSettingRequest, NetworkSwitchBase, NetworkSwitchResponse,
    PowerEventResponse, PowerEventListResponse,
    AlertResponse, AlertListResponse, AlertRuleResponse, AlertRuleCreate, AlertRuleUpdate
)
from services.analytics_service import calculate_device_energy_savings, calculate_system_analytics
from services.scheduler_service import determine_command_for_device, update_device_status, log_power_event
from services.wol_service import wake_device

# Initialize FastAPI app
app = FastAPI(
    title="Smart Power Management System",
    description="Central API for lab computer power management",
    version="1.0.0"
)

# CORS middleware for dashboard access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pending commands for devices (in-memory queue)
pending_commands: dict[str, dict] = {}


@app.on_event("startup")
async def startup_event():
    """Initialize database on startup"""
    init_db()
    print("[SUCCESS] Database initialized")


# ============ Heartbeat Endpoint ============

@app.post("/api/heartbeat", response_model=HeartbeatResponse)
async def receive_heartbeat(
    heartbeat: HeartbeatRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Receive heartbeat from client agent
    Returns command for agent to execute
    """
    # Find or create device
    device = db.query(Device).filter(Device.device_id == heartbeat.device_id).first()
    
    if not device:
        # Register new device
        device = Device(
            device_id=heartbeat.device_id,
            hostname=heartbeat.hostname,
            ip_address=heartbeat.ip_address,
            mac_address=heartbeat.mac_address,
            os_name=heartbeat.os_name,
            os_version=heartbeat.os_version,
            cpu_model=heartbeat.cpu_model,
            ram_total_gb=heartbeat.ram_total_gb,
            system_type=heartbeat.system_type or "lab"
        )
        db.add(device)
        db.commit()
        db.refresh(device)
        print(f"📱 New device registered: {heartbeat.hostname}")
    
    # Update device status
    device.ip_address = heartbeat.ip_address
    device.idle_seconds = heartbeat.idle_seconds
    device.cpu_usage = heartbeat.cpu_usage
    device.ram_usage = heartbeat.ram_usage
    device.last_heartbeat = datetime.utcnow()
    device.status = update_device_status(db, device, heartbeat.idle_seconds)
    
    # Update specs if provided
    if heartbeat.os_name:
        device.os_name = heartbeat.os_name
    if heartbeat.os_version:
        device.os_version = heartbeat.os_version
    if heartbeat.cpu_model:
        device.cpu_model = heartbeat.cpu_model
    if heartbeat.ram_total_gb:
        device.ram_total_gb = heartbeat.ram_total_gb
    if heartbeat.system_type:
        # Prevent agents from overwriting 'admin' status once set in DB
        if str(device.system_type).lower().strip() != "admin":
            device.system_type = heartbeat.system_type
    
    # Update uptime/idle tracking
    device.total_uptime_minutes += 1  # Approximate: each heartbeat = ~30s, count as 1 min
    if heartbeat.idle_seconds > 300:  # 5 mins idle
        device.total_idle_minutes += 1
    
    db.commit()
    
    # Log heartbeat for history
    hb_log = Heartbeat(
        device_id=device.id,
        idle_seconds=heartbeat.idle_seconds,
        cpu_usage=heartbeat.cpu_usage,
        ram_usage=heartbeat.ram_usage,
        status=device.status
    )
    db.add(hb_log)
    db.commit()
    
    # Check for pending manual command
    if heartbeat.device_id in pending_commands:
        cmd = pending_commands.pop(heartbeat.device_id)
        # Update last_power_state if it's a state-changing command
        if cmd["command"] in [CommandType.SLEEP, CommandType.HIBERNATE, CommandType.SHUTDOWN]:
            device.last_power_state = cmd["command"]
            log_power_event(db, device.id, cmd["command"], "manual")
            
        return HeartbeatResponse(
            command=cmd["command"],
            message=cmd.get("message"),
            grace_period_seconds=60
        )
    
    # Determine automatic command based on rules
    command, message = determine_command_for_device(db, device)
    
    if command != CommandType.STAY_AWAKE:
        device.last_power_state = command
        log_power_event(db, device.id, command, "auto")
    elif device.last_power_state in ["SLEEP", "HIBERNATE", "SHUTDOWN"]:
        # If device responds ACTIVE after being SLEEP/SHUTDOWN, mark as ACTIVE
        device.last_power_state = "ACTIVE"
        log_power_event(db, device.id, "WAKE", "auto")
    
    grace_period = int(db.query(Settings).filter(Settings.key == "grace_period_seconds").first().value or "60")
    
    return HeartbeatResponse(
        command=command,
        message=message,
        grace_period_seconds=grace_period
    )


# ============ Device Endpoints ============

@app.get("/api/devices", response_model=DeviceListResponse)
async def list_devices(db: Session = Depends(get_db)):
    """Get all registered devices with status counts"""
    devices = db.query(Device).all()
    
    # Update any devices that haven't sent heartbeat in 2+ minutes to offline
    timeout_seconds = int(db.query(Settings).filter(
        Settings.key == "heartbeat_timeout_seconds"
    ).first().value or "120")
    
    timeout_threshold = datetime.utcnow() - timedelta(seconds=timeout_seconds)
    
    for device in devices:
        # Special handling for admin systems: much longer timeout (1 hour)
        # Use strip and lower to be extremely robust
        sys_type = str(device.system_type or "").strip().lower()
        is_protected = "admin" in sys_type or device.hostname == "Sanjana"
        
        effective_timeout = 3600 if is_protected else timeout_seconds
        effective_threshold = datetime.utcnow() - timedelta(seconds=effective_timeout)
        
        if device.last_heartbeat and device.last_heartbeat < effective_threshold:
            if device.status != "offline":
                print(f"[WARNING] Marking device {device.hostname} ({sys_type}) as offline. LastHB: {device.last_heartbeat}, Threshold: {effective_threshold}")
                device.status = "offline"
                device.total_powered_off_minutes += 2  # Count offline time
        elif device.last_heartbeat and device.last_heartbeat >= effective_threshold:
            # Device has recent heartbeat - restore status if it was marked offline
            if device.status == "offline":
                print(f"[SUCCESS] Restoring device {device.hostname} to active (recent heartbeat)")
                device.status = "active"
    
    db.commit()
    
    # Count statuses
    active = sum(1 for d in devices if d.status == "active")
    idle = sum(1 for d in devices if d.status in ["passive", "deep_idle"])
    offline = sum(1 for d in devices if d.status == "offline")
    
    return DeviceListResponse(
        devices=[DeviceResponse.model_validate(d) for d in devices],
        total_count=len(devices),
        active_count=active,
        idle_count=idle,
        offline_count=offline
    )


@app.get("/api/devices/{device_id}", response_model=DeviceDetailResponse)
async def get_device_detail(device_id: str, db: Session = Depends(get_db)):
    """Get detailed info for a specific device"""
    device = db.query(Device).filter(Device.device_id == device_id).first()
    
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    # Calculate energy savings for this device
    savings = calculate_device_energy_savings(db, device)
    
    # Get recent heartbeat history (last hour)
    one_hour_ago = datetime.utcnow() - timedelta(hours=1)
    recent_heartbeats = db.query(Heartbeat).filter(
        Heartbeat.device_id == device.id,
        Heartbeat.timestamp >= one_hour_ago
    ).order_by(Heartbeat.timestamp.desc()).limit(120).all()
    
    cpu_history = [
        {"timestamp": hb.timestamp.isoformat(), "value": hb.cpu_usage}
        for hb in reversed(recent_heartbeats)
    ]
    
    idle_history = [
        {"timestamp": hb.timestamp.isoformat(), "value": hb.idle_seconds}
        for hb in reversed(recent_heartbeats)
    ]
    
    response = DeviceDetailResponse(
        id=device.id,
        device_id=device.device_id,
        hostname=device.hostname,
        ip_address=device.ip_address,
        mac_address=device.mac_address,
        status=device.status,
        last_heartbeat=device.last_heartbeat,
        idle_seconds=device.idle_seconds,
        cpu_usage=device.cpu_usage,
        ram_usage=device.ram_usage,
        os_name=device.os_name,
        os_version=device.os_version,
        cpu_model=device.cpu_model,
        ram_total_gb=device.ram_total_gb,
        system_type=device.system_type or "lab",
        last_power_state=device.last_power_state or "ACTIVE",
        total_uptime_minutes=device.total_uptime_minutes,
        total_idle_minutes=device.total_idle_minutes,
        total_powered_off_minutes=device.total_powered_off_minutes,
        energy_saved_kwh=savings["energy_saved_kwh"],
        cost_saved_rupees=savings["cost_saved_rupees"],
        co2_reduced_kg=savings["co2_reduced_kg"],
        recent_cpu_history=cpu_history,
        recent_idle_history=idle_history
    )
    
    return response


@app.post("/api/devices/{device_id}/command")
async def send_command(device_id: str, request: SendCommandRequest, db: Session = Depends(get_db)):
    """Queue a command for a device"""
    device = db.query(Device).filter(Device.device_id == device_id).first()
    
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    if request.command == CommandType.SHUTDOWN:
        # Log power event
        log_power_event(db, device.id, "SHUTDOWN", "manual")
    
    # Special handling for Wake-on-LAN
    if request.command == CommandType.STAY_AWAKE and device.status == "offline":
        # This is a wake command
        if device.mac_address:
            success = wake_device(device.mac_address)
            log_power_event(db, device.id, "WOL", "manual")
            return {"status": "WOL packet sent", "success": success}
    
    # Queue command for next heartbeat
    pending_commands[device_id] = {
        "command": request.command,
        "message": request.message
    }
    
    return {"status": "Command queued", "device_id": device_id, "command": request.command}


@app.post("/api/devices/{device_id}/wake")
async def wake_device_endpoint(device_id: str, db: Session = Depends(get_db)):
    """Send Wake-on-LAN to a device"""
    device = db.query(Device).filter(Device.device_id == device_id).first()
    
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    
    if not device.mac_address:
        raise HTTPException(status_code=400, detail="Device has no MAC address")
    
    success = wake_device(device.mac_address)
    log_power_event(db, device.id, "WOL", "manual")
    
    return {"status": "WOL packet sent", "success": success, "mac": device.mac_address}


@app.post("/api/devices/wake-all")
async def wake_all_devices(db: Session = Depends(get_db)):
    """Send Wake-on-LAN to all offline or sleeping devices"""
    # Target offline devices AND those we think are in sleep/shutdown
    devices_to_wake = db.query(Device).filter(
        (Device.status == "offline") | 
        (Device.last_power_state.in_(["SLEEP", "SHUTDOWN"]))
    ).all()
    
    results = []
    for device in devices_to_wake:
        if device.mac_address:
            success = wake_device(device.mac_address)
            log_power_event(db, device.id, "WOL", "manual")
            results.append({"device_id": device.device_id, "hostname": device.hostname, "success": success})
    
    return {"status": "WOL packets sent", "count": len(results), "results": results}


@app.post("/api/devices/shutdown-all-idle")
async def shutdown_all_idle(db: Session = Depends(get_db)):
    """Queue shutdown for all deeply idle devices"""
    idle_devices = db.query(Device).filter(Device.status == "deep_idle").all()
    
    for device in idle_devices:
        pending_commands[device.device_id] = {
            "command": CommandType.SHUTDOWN,
            "message": "Emergency shutdown triggered by admin"
        }
        log_power_event(db, device.id, "SHUTDOWN", "manual")
    
    return {"status": "Shutdown queued", "count": len(idle_devices)}


@app.post("/api/devices/hibernate-all-idle")
async def hibernate_all_idle(db: Session = Depends(get_db)):
    """Queue hibernate for all deeply idle devices"""
    idle_devices = db.query(Device).filter(Device.status == "deep_idle").all()
    
    for device in idle_devices:
        pending_commands[device.device_id] = {
            "command": CommandType.HIBERNATE,
            "message": "Manual group hibernation triggered by admin"
        }
        log_power_event(db, device.id, "HIBERNATE", "manual")
    
    return {"status": "Hibernation queued", "count": len(idle_devices)}


@app.post("/api/devices/sleep-all-idle")
async def sleep_all_idle(db: Session = Depends(get_db)):
    """Queue sleep (suspend) for all deeply idle devices"""
    idle_devices = db.query(Device).filter(Device.status == "deep_idle").all()
    
    for device in idle_devices:
        pending_commands[device.device_id] = {
            "command": CommandType.SLEEP,
            "message": "Manual group sleep triggered by admin"
        }
        log_power_event(db, device.id, "SLEEP", "manual")
    
    return {"status": "Sleep queued", "count": len(idle_devices)}


# ============ Analytics Endpoints ============

@app.get("/api/analytics", response_model=AnalyticsResponse)
async def get_analytics(db: Session = Depends(get_db)):
    """Get system-wide analytics"""
    return calculate_system_analytics(db)


# ============ Settings Endpoints ============

@app.get("/api/settings", response_model=SettingsResponse)
async def get_settings(db: Session = Depends(get_db)):
    """Get all system settings"""
    settings = db.query(Settings).all()
    return SettingsResponse(
        settings=[SettingItem(key=s.key, value=s.value, description=s.description) for s in settings]
    )


@app.put("/api/settings")
async def update_setting(request: UpdateSettingRequest, db: Session = Depends(get_db)):
    """Update a setting value"""
    setting = db.query(Settings).filter(Settings.key == request.key).first()
    
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    
    setting.value = request.value
    db.commit()
    
    return {"status": "Setting updated", "key": request.key, "value": request.value}


# ============ Network Switch Endpoints ============

@app.get("/api/switches", response_model=List[NetworkSwitchResponse])
async def list_switches(db: Session = Depends(get_db)):
    """Get all network switches"""
    switches = db.query(NetworkSwitch).all()
    
    result = []
    for switch in switches:
        result.append(NetworkSwitchResponse(
            id=switch.id,
            name=switch.name,
            location=switch.location,
            smart_plug_ip=switch.smart_plug_ip,
            smart_plug_type=switch.smart_plug_type,
            is_powered=switch.is_powered,
            connected_device_ids=json.loads(switch.connected_device_ids or "[]")
        ))
    
    return result


@app.post("/api/switches")
async def create_switch(switch: NetworkSwitchBase, db: Session = Depends(get_db)):
    """Create a new network switch mapping"""
    new_switch = NetworkSwitch(
        name=switch.name,
        location=switch.location,
        smart_plug_ip=switch.smart_plug_ip,
        smart_plug_type=switch.smart_plug_type,
        connected_device_ids=json.dumps(switch.connected_device_ids)
    )
    db.add(new_switch)
    db.commit()
    db.refresh(new_switch)
    
    return {"status": "Switch created", "id": new_switch.id}


# ============ Health Check ============

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}


# ============ Power Events (Activity Logs) ============

@app.get("/api/events", response_model=PowerEventListResponse)
async def list_power_events(
    device_id: str = None,
    event_type: str = None,
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """Get power events with optional filtering"""
    query = db.query(PowerEvent)
    
    if device_id:
        device = db.query(Device).filter(Device.device_id == device_id).first()
        if device:
            query = query.filter(PowerEvent.device_id == device.id)
    
    if event_type:
        query = query.filter(PowerEvent.event_type == event_type)
    
    total_count = query.count()
    events = query.order_by(PowerEvent.timestamp.desc()).offset(offset).limit(limit).all()
    
    # Build response with device info
    event_responses = []
    for event in events:
        device = db.query(Device).filter(Device.id == event.device_id).first()
        event_responses.append(PowerEventResponse(
            id=event.id,
            device_id=event.device_id,
            device_hostname=device.hostname if device else None,
            device_ip=device.ip_address if device else None,
            event_type=event.event_type,
            triggered_by=event.triggered_by,
            timestamp=event.timestamp
        ))
    
    return PowerEventListResponse(
        events=event_responses,
        total_count=total_count,
        page=offset // limit + 1,
        page_size=limit
    )


@app.delete("/api/events/{event_id}")
async def delete_power_event(event_id: int, db: Session = Depends(get_db)):
    """Delete an activity log entry"""
    event = db.query(PowerEvent).filter(PowerEvent.id == event_id).first()
    
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    db.delete(event)
    db.commit()
    
    return {"status": "Event deleted", "id": event_id}


# ============ Alerts Endpoints ============

@app.get("/api/alerts", response_model=AlertListResponse)
async def list_alerts(
    is_acknowledged: bool = None,
    severity: str = None,
    db: Session = Depends(get_db)
):
    """Get all alerts with optional filtering"""
    query = db.query(Alert)
    
    if is_acknowledged is not None:
        query = query.filter(Alert.is_acknowledged == is_acknowledged)
    
    if severity:
        query = query.filter(Alert.severity == severity)
    
    alerts = query.order_by(Alert.created_at.desc()).all()
    
    # Build response with device info
    alert_responses = []
    for alert in alerts:
        device = db.query(Device).filter(Device.id == alert.device_id).first() if alert.device_id else None
        alert_responses.append(AlertResponse(
            id=alert.id,
            device_id=alert.device_id,
            device_hostname=device.hostname if device else None,
            alert_type=alert.alert_type,
            message=alert.message,
            severity=alert.severity,
            is_acknowledged=alert.is_acknowledged,
            created_at=alert.created_at
        ))
    
    unacknowledged = sum(1 for a in alerts if not a.is_acknowledged)
    
    return AlertListResponse(
        alerts=alert_responses,
        total_count=len(alerts),
        unacknowledged_count=unacknowledged
    )


@app.post("/api/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: int, db: Session = Depends(get_db)):
    """Acknowledge an alert"""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    alert.is_acknowledged = True
    alert.acknowledged_at = datetime.utcnow()
    db.commit()
    
    return {"status": "Alert acknowledged", "id": alert_id}


@app.delete("/api/alerts/{alert_id}")
async def delete_alert(alert_id: int, db: Session = Depends(get_db)):
    """Delete/dismiss an alert"""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    db.delete(alert)
    db.commit()
    
    return {"status": "Alert deleted", "id": alert_id}


# ============ Alert Rules Endpoints ============

@app.get("/api/alert-rules", response_model=List[AlertRuleResponse])
async def list_alert_rules(db: Session = Depends(get_db)):
    """Get all alert rules"""
    rules = db.query(AlertRule).all()
    return [AlertRuleResponse(
        id=r.id,
        name=r.name,
        rule_type=r.rule_type,
        threshold_value=r.threshold_value,
        is_enabled=r.is_enabled,
        created_at=r.created_at
    ) for r in rules]


@app.post("/api/alert-rules", response_model=AlertRuleResponse)
async def create_alert_rule(rule: AlertRuleCreate, db: Session = Depends(get_db)):
    """Create a new alert rule"""
    new_rule = AlertRule(
        name=rule.name,
        rule_type=rule.rule_type,
        threshold_value=rule.threshold_value,
        is_enabled=rule.is_enabled
    )
    db.add(new_rule)
    db.commit()
    db.refresh(new_rule)
    
    return AlertRuleResponse(
        id=new_rule.id,
        name=new_rule.name,
        rule_type=new_rule.rule_type,
        threshold_value=new_rule.threshold_value,
        is_enabled=new_rule.is_enabled,
        created_at=new_rule.created_at
    )


@app.put("/api/alert-rules/{rule_id}", response_model=AlertRuleResponse)
async def update_alert_rule(rule_id: int, rule: AlertRuleUpdate, db: Session = Depends(get_db)):
    """Update an alert rule"""
    db_rule = db.query(AlertRule).filter(AlertRule.id == rule_id).first()
    
    if not db_rule:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    
    if rule.name is not None:
        db_rule.name = rule.name
    if rule.threshold_value is not None:
        db_rule.threshold_value = rule.threshold_value
    if rule.is_enabled is not None:
        db_rule.is_enabled = rule.is_enabled
    
    db.commit()
    db.refresh(db_rule)
    
    return AlertRuleResponse(
        id=db_rule.id,
        name=db_rule.name,
        rule_type=db_rule.rule_type,
        threshold_value=db_rule.threshold_value,
        is_enabled=db_rule.is_enabled,
        created_at=db_rule.created_at
    )


@app.delete("/api/alert-rules/{rule_id}")
async def delete_alert_rule(rule_id: int, db: Session = Depends(get_db)):
    """Delete an alert rule"""
    rule = db.query(AlertRule).filter(AlertRule.id == rule_id).first()
    
    if not rule:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    
    db.delete(rule)
    db.commit()
    
    return {"status": "Alert rule deleted", "id": rule_id}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
