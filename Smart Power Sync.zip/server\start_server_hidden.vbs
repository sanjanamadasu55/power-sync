Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "c:\Users\Lenovo\Desktop\smart power execution\server"
WshShell.Run "pythonw -m uvicorn main:app --host 0.0.0.0 --port 8000", 0, False
