@echo off
echo ========================================
echo   PowerSync Installer Builder
echo ========================================
echo.

REM Check if PyInstaller is installed
pip show pyinstaller >nul 2>&1
if errorlevel 1 (
    echo Installing PyInstaller...
    pip install pyinstaller
)

echo.
echo Building PowerSync Installer EXE...
echo.

pyinstaller --onefile --windowed --name "PowerSync_Installer" --icon=NONE --uac-admin --add-data "agent;agent" --add-data "server;server" --add-data "dashboard;dashboard" installer_gui.py

echo.
echo ========================================
if exist "dist\PowerSync_Installer.exe" (
    echo SUCCESS! EXE created at:
    echo   dist\PowerSync_Installer.exe
    echo.
    echo You can now distribute this file.
    copy "dist\PowerSync_Installer.exe" "PowerSync_Installer.exe" >nul
    echo Also copied to: PowerSync_Installer.exe
) else (
    echo BUILD FAILED! Check errors above.
)
echo ========================================
pause
